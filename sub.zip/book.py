

class Book:
    def __init__(self, score):
        self.score = int(score)

    def toString(self):

        return ""